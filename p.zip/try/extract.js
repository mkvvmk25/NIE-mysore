function fun(p) {
	fin = p.map((e) => {
		return {
			text: e.text,
			created_at: e.created_at,
			username: e.user.username,
		};
	});

	fin.sort((a, b) => a.created_at - b.created_at);
	let cnt = 1;
	fin.forEach((e) => {
		if (cnt == 1) e.points = 1000;
		else if (cnt == 2) e.points = 500;
		else e.points = 250;
		// console.log(e);
		cnt++;
	});

	return fin;
}

function k(p) {
	for (let index = 0; index < p.length - 1; index++) {
		if (p[index].created_at < p[index + 1].created_at) {
			console.log(
				new Date(p[index].created_at * 1000).toLocaleString("en-IN", {
					timeZone: "Asia/Kolkata",
				}),
				"12"
			);
		}
	}
}

module.exports = fun;
