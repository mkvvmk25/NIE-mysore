let posts = [
	require("./one"),
	require("./two"),
	require("./three"),
	require("./four"),
	require("./five"),
	require("./six"),
	require("./seven"),
	require("./eight"),
	require("./nine"),
	require("./ten"),
	require("./eleven"),
	require("./twelve"),
	require("./thirteen"),
	require("./fourteen"),
];

// console.log(posts.length);

let k = {
	username: {
		points: 0,
		answers: {
			1: "ans",
		},
	},
};
let usersPoints = {};
for (let i = 0; i < posts.length; i++) {
	let usersInPost = posts[i];
	for (let j = 0; j < usersInPost.length; j++) {
		let data = usersInPost[j];
		let userName = data["username"];
		let answer = data["text"];
		let points = data["points"];

		if (!usersPoints[userName]) {
			// if user is not present
			usersPoints[`${userName}`] = {
				points: points,
				answers: {
					[i + 1]: answer,
				},
			};
		} else {
			// if user is present
			usersPoints[userName].points += points;
			usersPoints[userName]["answers"] = {
				...usersPoints[userName]["answers"],
				[i + 1]: answer,
			};
		}
	}
}
// console.log(usersPoints);

let users = Object.keys(usersPoints);

let usersArray = users.map((user) => {
	return { ...usersPoints[`${user}`], userName: user };
});
// console.log(usersArray, "✅✅✅✅");
usersArray.sort((u1, u2) => -u1.points + u2.points);
// console.log(
// 	usersArray.map((u) => u.points),
// 	"✅✅✅✅"
// );
// console.log(usersArray.slice(0,10));
let userAllAns = usersArray.filter((u) => Object.keys(u.answers).length >= 13);
console.log(userAllAns, userAllAns.length);
